import json
import requests

def lambda_handler(event, context):
    metadata_url = event['queryStringParameters']['metadata_url']
    response = requests.get(metadata_url)
    nft_metadata = response.json()

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps(nft_metadata)
    }
